#include <bits/stdc++.h>
#include "Add.h"
using namespace std;
int main()
{
    int a, b;
    cin >> a >> b;
    cout << add(a, b) << endl;
    return 0;
}
