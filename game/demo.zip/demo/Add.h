#ifndef ADD_H_INCLUDED
#define ADD_H_INCLUDED

int add(int a, int b);

#endif // ADD_H_INCLUDED
